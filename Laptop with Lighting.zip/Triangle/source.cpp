#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include "glm/ext.hpp"
#include <glm/gtc/matrix_transform.hpp>
#include <iostream>
#include <vector>
#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>

// Vertex Shader source code
const char* vertexShaderSource = R"glsl(
#version 330 core
layout (location = 0) in vec3 position; // Vertex position
layout (location = 1) in vec2 texCoords; // Texture coordinates
layout (location = 2) in vec3 normal; // Normal vector for lighting calculations

out vec2 TexCoords;
out vec3 FragPos; // Position of the fragment for lighting
out vec3 Normal; // Normal for lighting calculations

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    FragPos = vec3(model * vec4(position, 1.0f)); // Convert position to world coordinates
    Normal = mat3(transpose(inverse(model))) * normal; // Convert normal to world coordinates
    TexCoords = texCoords;
    gl_Position = projection * view * model * vec4(position, 1.0f);
}
)glsl";

// Fragment Shader source code
const char* fragmentShaderSource = R"glsl(
#version 330 core
out vec4 FragColor;

in vec2 TexCoords;
in vec3 FragPos; // Received from vertex shader for lighting calculations
in vec3 Normal; // Received from vertex shader for lighting calculations

uniform sampler2D texture1; // First texture sampler
uniform sampler2D texture2; // Second texture sampler
uniform int textureSelector; // Variable to select which texture to use (1 for texture1, 2 for texture2)
uniform vec4 overrideColor; // Solid color override for non-textured rendering
uniform int useTexture; // Flag to determine whether to use texture or solid color

// Lighting uniforms
uniform vec3 lightPos; // Position of the light source
uniform vec3 viewPos; // Position of the camera
uniform vec3 lightColor; // Color of the light source

void main()
{
    // Ambient lighting
    float ambientStrength = 0.1;
    vec3 ambient = ambientStrength * lightColor;

    // Diffuse lighting
    vec3 norm = normalize(Normal);
    vec3 lightDir = normalize(lightPos - FragPos);
    float diff = max(dot(norm, lightDir), 0.0);
    vec3 diffuse = diff * lightColor;

    // Specular lighting
    float specularStrength = 0.5;
    vec3 viewDir = normalize(viewPos - FragPos);
    vec3 reflectDir = reflect(-lightDir, norm);
    float spec = pow(max(dot(viewDir, reflectDir), 0.0), 32);
    vec3 specular = specularStrength * spec * lightColor;

    // Calculate final color based on lighting and texture
    vec3 objectColor;
    if (useTexture == 1) {
        if (textureSelector == 1) {
            objectColor = texture(texture1, TexCoords).rgb; // Use first texture
        } else if (textureSelector == 2) {
            objectColor = texture(texture2, TexCoords).rgb; // Use second texture
        }
    } else {
        objectColor = overrideColor.rgb; // Use solid color
    }

    vec3 finalColor = (ambient + diffuse + specular) * objectColor;
    FragColor = vec4(finalColor, 1.0);
}

)glsl";


glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 3.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
bool firstMouse = true;
float yaw = -90.0f;  // yaw is initialized to -90.0 degrees since a yaw of 0.0 results in a direction vector pointing to the right
float pitch = 0.0f;
float lastX = 800.0f / 2.0;
float lastY = 600.0 / 2.0;
float fov = 45.0f;
float cameraSpeed = .01f;
bool isPerspective = true;

void processInput(GLFWwindow* window) {

    static bool pKeyWasPressed = false;
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) {
        if (!pKeyWasPressed) { // Simple debounce mechanism
            isPerspective = !isPerspective;
            pKeyWasPressed = true;
        }
    }
    else {
        pKeyWasPressed = false;
    }    
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        cameraPos += cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        cameraPos -= cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        cameraPos -= cameraSpeed * cameraUp;
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        cameraPos += cameraSpeed * cameraUp;

}


void mouse_callback(GLFWwindow* window, double xpos, double ypos) {
    if (firstMouse) {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos; // reversed since y-coordinates range from bottom to top
    lastX = xpos;
    lastY = ypos;

    float sensitivity = 0.1f;
    xoffset *= sensitivity;
    yoffset *= sensitivity;

    yaw += xoffset;
    pitch += yoffset;

    if (pitch > 89.0f)
        pitch = 89.0f;
    if (pitch < -89.0f)
        pitch = -89.0f;

    glm::vec3 front;
    front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    front.y = sin(glm::radians(pitch));
    front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
    cameraFront = glm::normalize(front);
}



void scroll_callback(GLFWwindow* window, double xoffset, double yoffset) {
    cameraSpeed += yoffset * 0.005; // Adjust the speed by a small amount based on scroll
    if (cameraSpeed < 0.0005) // Prevent the camera speed from becoming negative
        cameraSpeed = 0.0005;
    if (cameraSpeed > 0.2) // Cap the camera speed to avoid it becoming too fast
        cameraSpeed = 0.2;
}



void addKeyVertices(float x, float y, float z, float width, float height, float depth, std::vector<float>& vertices) {
    float w = width / 2.0f;
    float h = height / 2.0f;
    float d = depth / 2.0f;

    std::vector<float> keyVertices = {
        // Front face
        x - w, y - h, z + d,   x + w, y - h, z + d,   x + w, y + h, z + d,
        x + w, y + h, z + d,   x - w, y + h, z + d,   x - w, y - h, z + d,
        // Right face
        x + w, y - h, z + d,   x + w, y - h, z - d,   x + w, y + h, z - d,
        x + w, y + h, z - d,   x + w, y + h, z + d,   x + w, y - h, z + d,
        // Back face
        x + w, y - h, z - d,   x - w, y - h, z - d,   x - w, y + h, z - d,
        x - w, y + h, z - d,   x + w, y + h, z - d,   x + w, y - h, z - d,
        // Left face
        x - w, y - h, z - d,   x - w, y - h, z + d,   x - w, y + h, z + d,
        x - w, y + h, z + d,   x - w, y + h, z - d,   x - w, y - h, z - d,
        // Top face
        x - w, y + h, z + d,   x + w, y + h, z + d,   x + w, y + h, z - d,
        x + w, y + h, z - d,   x - w, y + h, z - d,   x - w, y + h, z + d,
        // Bottom face
        x - w, y - h, z - d,   x + w, y - h, z - d,   x + w, y - h, z + d,
        x + w, y - h, z + d,   x - w, y - h, z + d,   x - w, y - h, z - d,
    };

    vertices.insert(vertices.end(), keyVertices.begin(), keyVertices.end());
}


int main() {
    // Initialize GLFW
    glfwInit();

    glfwWindowHint(GLFW_DEPTH_BITS, 24);


    // Create a windowed mode window and its OpenGL context
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    GLFWwindow* window = glfwCreateWindow(800, 600, "OpenGL Laptop", nullptr, nullptr);
    if (window == nullptr) {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);

    glEnable(GL_DEPTH_TEST);

    // Initialize GLEW
    glewExperimental = GL_TRUE;
    if (glewInit() != GLEW_OK) {
        std::cout << "Failed to initialize GLEW" << std::endl;
        return -1;
    }

    // Define the viewport dimensions
    glViewport(0, 0, 800, 600);

    glfwSetCursorPosCallback(window, mouse_callback);
    glfwSetScrollCallback(window, scroll_callback);

    // Capture the mouse
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // Compile and link shaders
    unsigned int vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &vertexShaderSource, nullptr);
    glCompileShader(vertexShader);

    unsigned int fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShader, 1, &fragmentShaderSource, nullptr);
    glCompileShader(fragmentShader);

    unsigned int shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader);
    glAttachShader(shaderProgram, fragmentShader);
    glLinkProgram(shaderProgram);

    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);



    // Desk dimensions and position
    float deskWidth = 6.0f;  // Width of the desk
    float deskDepth = 2.0f;  // Depth of the desk
    float deskHeight = 0.2f;  // Thickness of the desk
    float deskY = 0.00f;  // Y position of the desk

    float deskVertices[] = {
        // Position                 // Texture Coords
        // Top face
        -deskWidth / 2, deskY, -deskDepth / 2,  0.0f, 0.0f, // Top Left
         deskWidth / 2, deskY, -deskDepth / 2,  1.0f, 0.0f, // Top Right
         deskWidth / 2, deskY,  deskDepth / 2,  1.0f, 1.0f, // Bottom Right
        -deskWidth / 2, deskY,  deskDepth / 2,  0.0f, 1.0f, // Bottom Left

        // Bottom face
        -deskWidth / 2, deskY - deskHeight, -deskDepth / 2,  0.0f, 0.0f, // Top Left
         deskWidth / 2, deskY - deskHeight, -deskDepth / 2,  1.0f, 0.0f, // Top Right
         deskWidth / 2, deskY - deskHeight,  deskDepth / 2,  1.0f, 1.0f, // Bottom Right
        -deskWidth / 2, deskY - deskHeight,  deskDepth / 2,  0.0f, 1.0f, // Bottom Left
    };


    unsigned int deskIndices[] = {
        // Top face
        0, 1, 2,
        2, 3, 0,
        // Bottom face
        4, 5, 6,
        6, 7, 4,
        // Sides
        0, 3, 7,
        7, 4, 0,
        1, 2, 6,
        6, 5, 1,
        0, 1, 5,
        5, 4, 0,
        3, 2, 6,
        6, 7, 3
    };



    float screenDepth = 0.02f; 

    float laptopScreenVertices[] = {
        // Positions           // Texture Coords
        // Front face
        -0.5f, 0.0f, -0.3f,    0.0f, 0.0f,
         0.5f, 0.0f, -0.3f,    1.0f, 0.0f,
         0.5f, 0.7f, -0.3f,    1.0f, 1.0f,
        -0.5f, 0.7f, -0.3f,    0.0f, 1.0f,
        // Back face 
        -0.5f, 0.0f, -0.3f - screenDepth, 0.0f, 0.0f,
         0.5f, 0.0f, -0.3f - screenDepth, 1.0f, 0.0f,
         0.5f, 0.7f, -0.3f - screenDepth, 1.0f, 1.0f,
        -0.5f, 0.7f, -0.3f - screenDepth, 0.0f, 1.0f,
    };

    unsigned int laptopScreenIndices[] = {
        // Front face
        0, 1, 2,
        2, 3, 0,
        // Back face
        4, 5, 6,
        6, 7, 4,
        // Top face
        3, 2, 6,
        6, 7, 3,
        // Bottom face
        0, 1, 5,
        5, 4, 0,
        // Left face
        0, 3, 7,
        7, 4, 0,
        // Right face
        1, 2, 6,
        6, 5, 1,
    };

    // Smaller rectangle for the actual screen (inner screen)
    float laptopActualScreenVertices[] = {
        -0.4f,  0.1f, -0.299f,  // Bottom Left
         0.4f,  0.1f, -0.299f,  // Bottom Right
         0.4f,  0.65f, -0.299f,  // Top Right
        -0.4f,  0.65f, -0.299f   // Top Left
    };

    // Define vertices for a cuboid (laptop base)
    float laptopBaseVertices[] = {
        // Positions            // Texture Coords
        // Bottom face
        -0.5f,  0.0f,  0.3f,    0.0f, 0.0f,
         0.5f,  0.0f,  0.3f,    1.0f, 0.0f,
         0.5f,  0.0f, -0.3f,    1.0f, 1.0f,
        -0.5f,  0.0f, -0.3f,    0.0f, 1.0f,
        // Top face
        -0.5f,  0.05f,  0.3f,   0.0f, 0.0f,
         0.5f,  0.05f,  0.3f,   1.0f, 0.0f,
         0.5f,  0.05f, -0.3f,   1.0f, 1.0f,
        -0.5f,  0.05f, -0.3f,   0.0f, 1.0f,
    };

    unsigned int laptopBaseIndices[] = {
        // Each pair of three indices form one triangle
        0, 1, 5,  // Front face
        0, 5, 4,
        1, 2, 6,  // Right face
        1, 6, 5,
        2, 3, 7,  // Back face
        2, 7, 6,
        3, 0, 4,  // Left face
        3, 4, 7,
        4, 5, 6,  // Top face
        4, 6, 7,
        0, 1, 2,  // Bottom face
        0, 2, 3
    };

    unsigned int texture1, texture2;
    // Load the first texture
    glGenTextures(1, &texture1);
    glBindTexture(GL_TEXTURE_2D, texture1);
   
    int width, height, nrChannels;
    unsigned char* data = stbi_load("C:\\Users\\samblanton\\source\\repos\\Laptop\\wood.jpeg", &width, &height, &nrChannels, 0);
    if (data) {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else {
        std::cout << "Failed to load texture 1" << std::endl;
    }
    stbi_image_free(data);

    // Load the second texture
    glGenTextures(1, &texture2);
    glBindTexture(GL_TEXTURE_2D, texture2);

    data = stbi_load("C:\\Users\\samblanton\\source\\repos\\Laptop\\mac_clam.jpg", &width, &height, &nrChannels, 0);
    if (data) {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else {
        std::cout << "Failed to load texture 2" << std::endl;
    }
    stbi_image_free(data);


// Setup for desk with textures
    unsigned int deskVAO, deskVBO, deskEBO;
    glGenVertexArrays(1, &deskVAO);
    glGenBuffers(1, &deskVBO);
    glGenBuffers(1, &deskEBO);
    glBindVertexArray(deskVAO);
    glBindBuffer(GL_ARRAY_BUFFER, deskVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(deskVertices), deskVertices, GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, deskEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(deskIndices), deskIndices, GL_STATIC_DRAW);

    // Position attribute for desk
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // Texture coordinate attribute for desk
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindVertexArray(0); // Unbind VAO to avoid accidental modifications

    unsigned int VBOs[2], VAOs[2], EBOs[2]; // One EBO for the screen and one for the base
    glGenVertexArrays(2, VAOs); // Generate Vertex Array Objects for the screen and base
    glGenBuffers(2, VBOs); // Generate Vertex Buffer Objects for the screen and base
    glGenBuffers(2, EBOs); // Generate Element Buffer Objects for the screen and base

    // Setup for the laptop screen with texture coordinates
    glBindVertexArray(VAOs[0]); // Bind the VAO for the laptop screen
    glBindBuffer(GL_ARRAY_BUFFER, VBOs[0]); // Bind the VBO for the laptop screen
    glBufferData(GL_ARRAY_BUFFER, sizeof(laptopScreenVertices), laptopScreenVertices, GL_STATIC_DRAW); // Upload the vertex data

    // Position attribute for the screen
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0); // Enable the vertex attribute array for position

    // Texture coordinate attribute for the screen
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1); // Enable the vertex attribute array for texture coordinates

    // Bind and set the EBO for the laptop screen
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBOs[0]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(laptopScreenIndices), laptopScreenIndices, GL_STATIC_DRAW);

    glBindVertexArray(0); // Unbind the VAO to prevent accidental modifications

    // Setup for the laptop base with texture coordinates
    glBindVertexArray(VAOs[1]); // Bind the VAO for the laptop base
    glBindBuffer(GL_ARRAY_BUFFER, VBOs[1]); // Bind the VBO for the laptop base
    glBufferData(GL_ARRAY_BUFFER, sizeof(laptopBaseVertices), laptopBaseVertices, GL_STATIC_DRAW); // Upload the vertex data

    // Position attribute for the base
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0); // Enable the vertex attribute array for position

    // Texture coordinate attribute for the base
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1); // Enable the vertex attribute array for texture coordinates

    // Bind and set the EBO for the laptop base
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBOs[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(laptopBaseIndices), laptopBaseIndices, GL_STATIC_DRAW);

    glBindVertexArray(0); // Unbind the VAO to prevent accidental modifications



    unsigned int actualScreenVAO, actualScreenVBO;
    glGenVertexArrays(1, &actualScreenVAO);
    glGenBuffers(1, &actualScreenVBO);

    // Bind the Vertex Array Object first
    glBindVertexArray(actualScreenVAO);

    // Bind and set the vertex buffer(s)
    glBindBuffer(GL_ARRAY_BUFFER, actualScreenVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(laptopActualScreenVertices), laptopActualScreenVertices, GL_STATIC_DRAW);

    // Configure the position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // Unbind the VAO to avoid accidental modification
    glBindVertexArray(0);



    std::vector<float> keyVertices;
    float keyWidth = 0.05f, keyHeight = 0.02f, keyDepth = 0.05f; 
    int numRows = 6, numCols = 10; 
    float baseTopY = 0.05f; 

    float startX = -0.25f; // Starting X position of the keys (left-right on the laptop base)
    float startZ = 0.1f;  // Starting Z position of the keys (up-down on the laptop base)
    float keySpacingX = 0.06f; // Spacing between keys left-right
    float keySpacingZ = 0.06f; // Spacing between keys up-down

    for (int row = 0; row < numRows; ++row) {
        for (int col = 0; col < numCols; ++col) {
            float x = startX + col * keySpacingX; // X position of the key
            float z = startZ - row * keySpacingZ; // Z position of the key
            float y = baseTopY;                   // Y position (height) of the key
            addKeyVertices(x, y, z, keyWidth, keyHeight, keyDepth, keyVertices);
        }
    }

    unsigned int keyVBO, keyVAO;
    glGenVertexArrays(1, &keyVAO);
    glGenBuffers(1, &keyVBO);

    glBindVertexArray(keyVAO);
    glBindBuffer(GL_ARRAY_BUFFER, keyVBO);
    glBufferData(GL_ARRAY_BUFFER, keyVertices.size() * sizeof(float), keyVertices.data(), GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // Unbind the VBO and VAO
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);


    // Light properties
    glm::vec3 lightPos(1.2f, 2.0f, 2.0f); // Adjust based on your scene
    glm::vec3 lightColor(1.0f, 1.0f, 1.0f); // White light


    // Main render loop
    while (!glfwWindowShouldClose(window)) {

        processInput(window);

        // Clear the color buffer
        glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // Modified line

        glActiveTexture(GL_TEXTURE0); // Activate the texture unit 0
        glBindTexture(GL_TEXTURE_2D, texture1); // Bind texture1

        // Use shader program
        glUseProgram(shaderProgram);



        // Set the texture selector 
        int textureSelectorLocation = glGetUniformLocation(shaderProgram, "textureSelector");
        glUniform1i(textureSelectorLocation, 2); 

        // Set the flag to use texture
        int useTextureLocation = glGetUniformLocation(shaderProgram, "useTexture");
        glUniform1i(useTextureLocation, 1); 



        // Create transformations
        glm::mat4 model = glm::mat4(1.0f);
        glm::mat4 view = glm::mat4(1.0f);
        glm::mat4 projection;
        if (isPerspective) {
            projection = glm::perspective(glm::radians(fov), 800.0f / 600.0f, 0.1f, 100.0f);
        }
        else {
            // Parameters for orthographic projection can be adjusted as needed
            float aspectRatio = 800.0f / 600.0f;
            projection = glm::ortho(-aspectRatio, aspectRatio, -1.0f, 1.0f, 0.1f, 100.0f);
        }

        view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);


        // Retrieve the matrix uniform locations
        unsigned int modelLoc = glGetUniformLocation(shaderProgram, "model");
        unsigned int viewLoc = glGetUniformLocation(shaderProgram, "view");
        unsigned int projLoc = glGetUniformLocation(shaderProgram, "projection");

        // Pass them to the shaders
        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));


        
        glActiveTexture(GL_TEXTURE0); // Activate the first texture unit
        glBindTexture(GL_TEXTURE_2D, texture1);
        glUniform1i(glGetUniformLocation(shaderProgram, "texture1"), 0);
        glUniform1i(glGetUniformLocation(shaderProgram, "textureSelector"), 1);

        // Set the view and light position uniforms
        glUniform3f(glGetUniformLocation(shaderProgram, "viewPos"), cameraPos.x, cameraPos.y, cameraPos.z);
        glUniform3f(glGetUniformLocation(shaderProgram, "lightPos"), lightPos.x, lightPos.y, lightPos.z);
        glUniform3f(glGetUniformLocation(shaderProgram, "lightColor"), lightColor.x, lightColor.y, lightColor.z);

        // Bind and draw the desk with its texture
        glBindVertexArray(deskVAO);
        glDrawElements(GL_TRIANGLES, sizeof(deskIndices) / sizeof(unsigned int), GL_UNSIGNED_INT, 0);

        glActiveTexture(GL_TEXTURE1); // Activate the first texture unit
        glBindTexture(GL_TEXTURE_2D, texture2);
        // Set the sampler to use the first texture unit
        glUniform1i(glGetUniformLocation(shaderProgram, "texture2"), 1);
        glUniform1i(glGetUniformLocation(shaderProgram, "textureSelector"), 2);

        // Draw the laptop base
        glBindVertexArray(VAOs[1]);
        glDrawElements(GL_TRIANGLES, sizeof(laptopBaseIndices) / sizeof(laptopBaseIndices[0]), GL_UNSIGNED_INT, 0);

        // Draw the laptop screen
        glBindVertexArray(VAOs[0]);
        glDrawElements(GL_TRIANGLES, sizeof(laptopScreenIndices) / sizeof(laptopScreenIndices[0]), GL_UNSIGNED_INT, 0);



        // Before drawing keys and actual screen
        glUniform1i(glGetUniformLocation(shaderProgram, "useTexture"), 0); // Disable texturing
        glUniform4f(glGetUniformLocation(shaderProgram, "overrideColor"), 0.0f, 0.0f, 0.0f, 1.0f); // Set color to black

        // Draw the actual screen
        glBindVertexArray(actualScreenVAO);
        glDrawArrays(GL_TRIANGLE_FAN, 0, 4);

        glBindVertexArray(keyVAO);
        int numKeys = numRows * numCols;
        for (int i = 0; i < numKeys; ++i) {
            glDrawArrays(GL_TRIANGLES, i * 36, 36); // 36 vertices per key
        }



        // Swap buffers and poll IO events
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    // Cleanup
    glDeleteVertexArrays(2, VAOs); 
    glDeleteBuffers(2, VBOs); 
    glDeleteBuffers(2, EBOs); 
    glDeleteProgram(shaderProgram); 

    glDeleteVertexArrays(1, &keyVAO); 
    glDeleteBuffers(1, &keyVBO); 

    glDeleteVertexArrays(1, &actualScreenVAO);
    glDeleteBuffers(1, &actualScreenVBO); 



    glfwTerminate();

    return 0;
}
